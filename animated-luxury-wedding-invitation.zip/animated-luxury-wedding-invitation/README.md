# Animated Luxury Wedding Invitation

This is a responsive Bengali + English + Arabic wedding invitation with:
- Click-to-open 3D-style envelope and sliding invitation card
- Gold wax seal and floating golden particles
- Live countdown
- Nikah, Walima, venue and Google Maps link

## Customize
Edit `weddingDetails` at the top of `script.js`. Change the demo names, dates, venue details and map URL. Use a local date/time in `weddingDate` formatted `YYYY-MM-DDTHH:MM:SS`.

## Publish on GitHub Pages
1. Download and extract this ZIP.
2. Create a GitHub repository (e.g. `wedding-invitation`).
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
4. Open Settings → Pages.
5. Choose Deploy from a branch → `main` → `/(root)` → Save.
6. Wait for publishing. The link will be `https://YOUR-USERNAME.github.io/wedding-invitation/`.

Google Fonts are loaded from Google Fonts, so the custom typography needs an internet connection. The site itself is static and works on GitHub Pages.
