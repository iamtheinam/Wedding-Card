// PERSONALIZE YOUR INVITATION: edit the values in this object.
const weddingDetails = {
  groom: "Groom's Name",
  bride: "Bride's Name",
  weddingDate: "2027-02-14T18:00:00", // YYYY-MM-DDTHH:MM:SS (local time)
  dateText: "14 February 2027 · 6:00 PM",
  nikahDate: "14 February 2027 · 6:00 PM",
  nikahVenue: "Venue name · City",
  walimaDate: "15 February 2027 · 7:00 PM",
  walimaVenue: "Venue name · City",
  venueName: "Wedding Venue",
  venueAddress: "Full venue address, City, State",
  mapUrl: "https://maps.google.com"
};

const byId = id => document.getElementById(id);
const put = (id, value) => { byId(id).textContent = value; };

put("groomName", weddingDetails.groom);
put("brideName", weddingDetails.bride);
put("miniNames", `${weddingDetails.groom} & ${weddingDetails.bride}`);
put("miniDate", weddingDetails.dateText);
put("dateDisplay", weddingDetails.dateText);
put("nikahDate", weddingDetails.nikahDate);
put("nikahVenue", weddingDetails.nikahVenue);
put("walimaDate", weddingDetails.walimaDate);
put("walimaVenue", weddingDetails.walimaVenue);
put("venueName", weddingDetails.venueName);
put("venueAddress", weddingDetails.venueAddress);
byId("mapLink").href = weddingDetails.mapUrl;

let opened = false;
byId("openEnvelope").addEventListener("click", () => {
  if (opened) return;
  opened = true;
  const opening = byId("opening");
  const invitation = byId("invitation");
  opening.classList.add("opening-out");
  window.setTimeout(() => {
    opening.style.display = "none";
    invitation.classList.add("show");
    invitation.setAttribute("aria-hidden", "false");
    window.scrollTo({top: 0, behavior: "smooth"});
  }, 2800);
});

function updateCountdown() {
  const target = new Date(weddingDetails.weddingDate).getTime();
  let remaining = target - Date.now();
  if (!Number.isFinite(target)) remaining = NaN;
  if (Number.isNaN(remaining)) {
    ["days","hours","minutes","seconds"].forEach(id => put(id, "--"));
    return;
  }
  if (remaining <= 0) remaining = 0;
  const values = {
    days: Math.floor(remaining / 86400000),
    hours: Math.floor((remaining % 86400000) / 3600000),
    minutes: Math.floor((remaining % 3600000) / 60000),
    seconds: Math.floor((remaining % 60000) / 1000)
  };
  Object.entries(values).forEach(([id, value]) => put(id, String(value).padStart(2, "0")));
}
updateCountdown();
window.setInterval(updateCountdown, 1000);
